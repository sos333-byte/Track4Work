Track4Work Android starter project
====================================
This is a native Android starter project for Track4Work.

It includes a working Android UI with:
- Dashboard
- Equipment
- Maintenance
- Vehicles & Trailers
- Fuel
- Inventory
- Incident / Damage
- Service Records
- Documents

Important: this environment can create the Android project source, but it does not include
the Android SDK/Gradle build environment needed to compile and sign an APK here.
The project can be opened in Android Studio and built into an APK.

This is intentionally the first native build. Cloud accounts, multi-business separation,
secure database, backups, PDF generation and subscriptions/payments are next.
